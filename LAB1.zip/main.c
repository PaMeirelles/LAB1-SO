// Rafael Paladini Meirelles 2111538
// Felipe Mello 1811435

#include "sum.h"
#include "test.h"
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>
#define NUM_PROCESSES 8

int main(void) {
  for(int i = 1000; i <= 100000000; i *= 10){
    complete_test(i);
  }
  return 0;
}