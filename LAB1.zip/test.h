void complete_test(int size);
void print_vector(int *vector, int size);
void test_sum(int size, char mode, void (*sum)(int *, int *, int *, int, int), char type_of_sum) ;